/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pokemonfinders;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

/**
 *
 * @author CK
 */
public class mainobj {
    public static JSONObject mainobject(String json){
        try{
            JSONParser parser = new JSONParser();
            Object object = parser.parse(json);
            JSONObject mainobj = (JSONObject) object; 
            
            return mainobj;
        }catch(Exception e){
            e.printStackTrace();
        }
        return null;
    }
}
