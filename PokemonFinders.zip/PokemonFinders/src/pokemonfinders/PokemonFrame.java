/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package pokemonfinders;

import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Scanner;
import javax.imageio.ImageIO;
import javax.net.ssl.HttpsURLConnection;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import java.sql.*;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

/**
 *
 * @author CK
 */
public class PokemonFrame extends javax.swing.JFrame {
    
    /**
     * Creates new form PokemonFrame
     */
    public PokemonFrame(String view) {
        //title
        setTitle("PokemonFinders");
        //frame
        initComponents();       
        //used to add a mouse listener to add to fav
        favorite();        
        history();
        //used if i click the view from history so it will auto search if click
        ApiToJson(apiconnect(view));
    }
    private String collectedData[] = new String[5];
    private int account_id=0;
    //to turn the api to json and print 
    private void ApiToJson(String json){
        try{
            String name="?";
            
            //used the class mainobj class
            JSONObject main = mainobj.mainobject(json);
            
            //getting the name from the json
            JSONArray array = (JSONArray) main.get("forms");
            
            for(int a = 0;a<array.size();a++){
                JSONObject in = (JSONObject) array.get(a);
                name = (String) in.get("name");
                lbl_name.setText(name);
            }
            
            //getting the url from the json to get the given picture
            JSONObject select = (JSONObject) main.get("sprites");
            String url = (String) select.get("front_default");
            //used to resize img and print the picture
            imageresize(url);                       

            //used to get the data from the json then turn it into json object
            JSONArray ar = (JSONArray) main.get("abilities");

            JSONObject obj = (JSONObject) ar.get(0);
            JSONObject show = (JSONObject) obj.get("ability");
            String ability = (String) show.get("name");
            lblability1.setText(ability);                

            //used to get the data from the api then turn it into json object
            JSONObject obj2 = (JSONObject) ar.get(1);
            JSONObject show2 = (JSONObject) obj2.get("ability");
            String ability2 = (String) show2.get("name");
            lblability2.setText(ability2); 

            //used to get the id from the api 
            long ids = (long) main.get("id");
            String id = String.valueOf(ids);
            lblid.setText(String.valueOf(ids)); 
            
            
            collectedData = getDataToHistory(name,ability,ability2,url,id);

            for(int a = 0;a<collectedData.length;a++){
                System.out.println(collectedData[a]);
            }                                  
        }
        catch(NullPointerException e){
            System.out.println("");
        }
        catch(Exception e){
            System.out.println(e);
        }
    }   
    //getting the api from the web
    public static String apiconnect(String searchs){        
        try{
            //i used the parameter to change the https so they can search idk if there is a good method than this but this is my first time using api and json.
            String url = "https://pokeapi.co/api/v2/pokemon/"+searchs;
            URL urlobj = new URL(url);
            HttpsURLConnection connect = (HttpsURLConnection) urlobj.openConnection();
            connect.setRequestMethod("GET");
            int response = connect.getResponseCode();
            System.out.println(response);
            if(response == connect.HTTP_OK){
                StringBuilder sb = new StringBuilder();
                Scanner scan = new Scanner(connect.getInputStream());
                while(scan.hasNext()){
                    sb.append(scan.nextLine());
                }
                String json = (String) sb.toString();               
                return json;
            }
            else{
                JOptionPane.showMessageDialog(null, "Sorry, it appears there are no results found!", "Error", JOptionPane.ERROR_MESSAGE);
                System.out.println("Failed");
            }
        }catch(Exception e){
            e.printStackTrace();
        }
        return null;
    }
    //i got this from the stack overflaw huge shout out to that dude but this is used to resize the image
    private static BufferedImage resizeImage(BufferedImage originalImage, int width, int height) {
        Image tempImage = originalImage.getScaledInstance(width, height, Image.SCALE_SMOOTH);
        BufferedImage resizedImage = new BufferedImage(width, height, BufferedImage.TYPE_INT_ARGB);

        Graphics2D g2d = resizedImage.createGraphics();
        g2d.drawImage(tempImage, 0, 0, null);
        g2d.dispose();

        return resizedImage;
    }
    public String Acc_id="";
    private static String poke_id="";
    
    private void setAccountID(String id){
        Acc_id = id;
    }
    private String getAccountID(){
        return Acc_id;
    }
    //idk if this has used but i dont want to delete it HAHAHA
    private void Checkingfavorite(String poke_id){      
        String DELETEHISTORY = "DELETE FROM tbl_history WHERE account_id=? and pokemon_id=?";
        Connection con = db_connect.connect();
        ResultSet rs = null;
        try{
            try(PreparedStatement st = con.prepareCall(DELETEHISTORY)){
                st.setString(1,getAccountID());
                st.setString(2,poke_id);
                int row = st.executeUpdate();
                if(row>0){
                    System.out.println("Delete complete");
                }
                else System.out.println("Failed to delete");
            }
        }catch(Exception e){
            e.printStackTrace();
        }
    }
    //store data to array
    private String[] getDataToHistory(String name,String ability,String ability2,String url,String id){
        String data[] = new String[5];
        data[0] = name;
        data[1] = ability;
        data[2] = ability2;
        data[3] = url;
        data[4] = id;   
        
        return data;
    }
    private void PassingToSQL(String ability1,String ability2,String picture,String name,String id){
        Connection con = db_connect.connect();
        LocalDate date = LocalDate.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        String dateString = date.format(formatter);
        String account_id = "";
        String pokemon_id = "";
        try{
            String QUERY = "SELECT * FROM tbl_account where username=? and password=? LIMIT 1";
            String INSERTAPI = "INSERT INTO tbl_api (ability1,ability2,picture,name,id,account_id) values (?,?,?,?,?,?)";
            String INSERTHISTORY = "INSERT INTO tbl_history (account_id,pokemon_id,time) values (?,?,?)";
            String GETTINGID = "SELECT * FROM tbl_api where account_id=? group by pokemon_id desc LIMIT 1";
            try(PreparedStatement st = con.prepareStatement(QUERY)){
                st.setString(1, loginn.user);
                st.setString(2,loginn.pass);
                ResultSet rs = st.executeQuery();
                if(rs.next()){
                    account_id = rs.getString("account_id");
                    setAccountID(account_id);
                }
                else System.out.println("No account found!");
            }
            //inserting the user search api
            try(PreparedStatement stm = con.prepareStatement(INSERTAPI)){
                stm.setString(1, ability1);
                stm.setString(2, ability2);
                stm.setString(3, picture);
                stm.setString(4, name);
                stm.setString(5, id);
                stm.setString(6, account_id);
                int rows = stm.executeUpdate();
                if(rows >0){
                    System.out.println("Successfully inserted to api");
                } else System.out.println("Failed insert");
            }
            //getting the latest id
            try (PreparedStatement s = con.prepareStatement(GETTINGID)){
                s.setString(1, account_id);
                ResultSet rss = s.executeQuery();
                if(rss.next()){
                    pokemon_id = rss.getString("pokemon_id");
                    poke_id = pokemon_id;
                }
                else System.out.println("no poke id found");
            }
            //inserting the history
            try(PreparedStatement stmt = con.prepareStatement(INSERTHISTORY)){
                stmt.setString(1, account_id);
                stmt.setString(2, pokemon_id);
                stmt.setString(3, dateString);
                int row = stmt.executeUpdate();
                if(row>0){
                    System.out.println("SUccessfully insert to history");
                }else System.out.println("failed");
            }
        }catch(Exception e){
            e.printStackTrace();
        }
    }
    private void findingfavorite(){
        Connection con = db_connect.connect();
        String num = "";
        String poke_id = "";
        String temp = "";
        int max = 0;
        try{
            String QUERY = "SELECT * FROM tbl_account where username=? and password=? LIMIT 1";  
            String Find = "SELECT * FROM tbl_api WHERE account_id=?";
            String FindFav = "SELECT * FROM tbl_history WHERE account_id=? and pokemon_id=? AND account_id=?";
            String Findmatch = "SELECT * FROM tbl_api WHERE pokemon_id=? AND id=? AND account_id=? ";
            String countrecored = "SELECT COUNT(*) AS MAX FROM tbl_history";
            //getting id
            try(PreparedStatement st = con.prepareStatement(QUERY)){
                st.setString(1, loginn.user);
                st.setString(2,loginn.pass);
                ResultSet rs = st.executeQuery();
                if(rs.next()){
                    num = rs.getString("account_id");
                }
                else System.out.println("No account found!");
            }
            //getting poke id
            try(PreparedStatement sts = con.prepareStatement(Find)){
                sts.setString(1, num);
                ResultSet rss = sts.executeQuery();
                if(rss.next()){
                    poke_id = rss.getString("pokemon_id");
                }
            }
            //counting max record
            try(PreparedStatement x = con.prepareStatement(countrecored)){
                ResultSet set = x.executeQuery();
                if(set.next()){
                    max = set.getInt("MAX");
                }else System.out.println("no record found");
            }
            boolean un = false;
            //searching match for fav
            try (PreparedStatement stt = con.prepareStatement(FindFav)) {
                boolean sam = true;
                int tempid = 5000;
                in = 5000;
                stt.setString(1, num);
                stt.setString(3, num); // Set the third parameter
                while (sam) {
                    stt.setInt(2, in);
                    ResultSet rst = stt.executeQuery();
                    if (rst.next() && sam) {
                        tempid = rst.getInt("pokemon_id");
                        try (PreparedStatement q = con.prepareStatement(Findmatch)) {
                            q.setString(3, num); // Set the third parameter for q
                            while (sam) {
                                q.setInt(1, in);
                                q.setString(2, lblid.getText());
                                ResultSet f = q.executeQuery();
                                if (f.next()) {
                                    System.out.println("It is already your favorite");
                                    again = false;
                                    fav.setIcon(new ImageIcon("C:\\Users\\CK\\Downloads\\done.png"));
                                    in = 5000;
                                    sam = false;
                                } else {
                                    if (in - 5000 <= max) {
                                        fav.setIcon(new ImageIcon("C:\\Users\\CK\\Downloads\\empty_star-removebg-preview.png"));
                                        un = true;
                                        sam = false;
                                        in = in - 5000;
                                        break;
                                    }                                    
                                    else {
                                      
                                    }
                                }
                                if(in >= 7500){
                                   sam = false;
                                }
                                in++;
                            }
                        }
                    } else {
                        in++;
                    }
                }
            }
            
        }catch(Exception e){
            e.printStackTrace();
        }
    }
    private int in = 5000;
    public boolean again = true;
    private void favorite(){       
        fav.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                System.out.println("clicked");
                //for if the result is already favorite
                if(again){
                    fav.setIcon(new ImageIcon("C:\\Users\\CK\\Downloads\\done.png"));
                    //String ability1,String ability2,String picture,String name,String id
                    PassingToSQL(collectedData[1],collectedData[2],collectedData[3],collectedData[0],collectedData[4]);
                    again = false;
                }
                //if not favorite
                else{
                    fav.setIcon(new ImageIcon("C:\\Users\\CK\\Downloads\\empty_star-removebg-preview.png"));
                    again = true;                     
                    Connection cons = db_connect.connect();
                    String pokemon_id="";
                    int acc_id=0;
                    
                    String  FindAccount = "SELECT * FROM tbl_account WHERE username=? AND password=?";
                    //getting jtextfield user and pass from loginn to retrieve id from database 
                    try(PreparedStatement s = cons.prepareStatement(FindAccount)){
                        s.setString(1, loginn.user);
                        s.setString(2,loginn.user);
                        ResultSet re = s.executeQuery();
                        if(re.next()){
                            acc_id = re.getInt("account_id");
                        }
                    }
                    catch(Exception c){
                        c.printStackTrace();
                    }
                    try{     
                        //getting the latest registered id from account id
                        String FindPokeID = "SELECT * FROM tbl_api WHERE account_id=? AND id=? GROUP BY pokemon_id ORDER BY pokemon_id ASC LIMIT 1";
                        try(PreparedStatement states = cons.prepareStatement(FindPokeID)){
                            states.setInt(1, acc_id);
                            states.setString(2, String.valueOf(lblid.getText()));
                            ResultSet rstt = states.executeQuery();
                            if(rstt.next()){
                                pokemon_id = rstt.getString("pokemon_id");
                                System.out.println(+ acc_id +" "+ lblid.getText() + " " + pokemon_id);
                            }else System.out.println("no pokemon_id  found" + account_id +" "+ lblid.getText());
                        }
                        String unfav = "DELETE FROM tbl_history WHERE account_id=? AND pokemon_id=? LIMIT 1";
                        //used to delete pokemone
                        try(PreparedStatement tate = cons.prepareStatement(unfav)){
                            tate.setInt(1,acc_id);
                            tate.setString(2, pokemon_id);
                            int response = tate.executeUpdate();
                            if(response >0){
                               System.out.println("You Sucessfully Unfavorite it!!");
                            }else System.out.println("unsucessful delete");
                        }
                    }catch(Exception f){
                        f.printStackTrace();
                    }
                }                    
            }                      
        });
    }
    //used to go to history
    private void history(){
        history.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                dispose();
                new histor().setVisible(true);
            }
        });
    }
    private void imageresize(String link){
        try{
            //getting the url link from the argument that i got from the api
            URL url = new URL(link);
            //i got the img link from the argument then turn it into a bufferedimage so i can resize it from the resizedImage method
            BufferedImage origimage = ImageIO.read(url);
            final int width = 250;
            final int height = 200;
            //this is the method that i got from the dude from the stack overflow
            BufferedImage resizedImage = resizeImage(origimage, width, height);
            
            //used to change the picture from the given search
            lblpicture.setIcon(new ImageIcon(resizedImage));
        }catch(Exception e){
            e.printStackTrace();
        }
        
    }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel4 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        text_search = new javax.swing.JTextField();
        btn_search = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        lbl_name = new javax.swing.JLabel();
        lblability1 = new javax.swing.JLabel();
        lblability2 = new javax.swing.JLabel();
        lblid = new javax.swing.JLabel();
        fav = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        lblpicture = new javax.swing.JLabel();
        history = new javax.swing.JLabel();

        jLabel4.setText("jLabel4");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(204, 204, 204));

        text_search.setBackground(new java.awt.Color(255, 255, 255));
        text_search.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        text_search.setForeground(new java.awt.Color(51, 51, 51));
        text_search.setText(" Search");
        text_search.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 153, 0), 2, true));

        btn_search.setBackground(new java.awt.Color(255, 255, 255));
        btn_search.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pictures/Search-ezgif.com-resize (2).gif"))); // NOI18N
        btn_search.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 153, 51), 2));
        btn_search.setFocusable(false);
        btn_search.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btn_searchMouseClicked(evt);
            }
        });
        btn_search.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_searchActionPerformed(evt);
            }
        });

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));
        jPanel2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 153, 0), 2));
        jPanel2.setForeground(new java.awt.Color(255, 255, 255));
        jPanel2.setMaximumSize(new java.awt.Dimension(320, 220));
        jPanel2.setPreferredSize(new java.awt.Dimension(320, 220));

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 153, 0));
        jLabel1.setText("Ability 1 :");

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 153, 0));
        jLabel2.setText("Ability 2 :");

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 153, 0));
        jLabel3.setText("I.D :");

        lbl_name.setFont(new java.awt.Font("Segoe UI", 1, 48)); // NOI18N
        lbl_name.setForeground(new java.awt.Color(255, 153, 0));
        lbl_name.setText("        ????");

        lblability1.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        lblability1.setForeground(new java.awt.Color(255, 153, 0));
        lblability1.setText("???");

        lblability2.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        lblability2.setForeground(new java.awt.Color(255, 153, 0));
        lblability2.setText("???");

        lblid.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        lblid.setForeground(new java.awt.Color(255, 153, 0));
        lblid.setText("???");

        fav.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pictures/empty_star-removebg-preview.png"))); // NOI18N
        fav.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lbl_name)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(lblability1))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(lblability2))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel3)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(lblid)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 156, Short.MAX_VALUE)
                        .addComponent(fav)))
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(lbl_name)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(lblability1))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(lblability2))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel3)
                        .addComponent(lblid))
                    .addComponent(fav, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(49, 49, 49))
        );

        jPanel3.setBackground(new java.awt.Color(255, 255, 255));
        jPanel3.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 153, 0), 2));

        lblpicture.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pictures/background (1).png"))); // NOI18N

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblpicture, javax.swing.GroupLayout.PREFERRED_SIZE, 250, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblpicture, javax.swing.GroupLayout.PREFERRED_SIZE, 199, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        history.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pictures/Screenshot_2024-06-16_225506-removebg-preview.png"))); // NOI18N
        history.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(text_search, javax.swing.GroupLayout.PREFERRED_SIZE, 346, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btn_search, javax.swing.GroupLayout.PREFERRED_SIZE, 64, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(53, 53, 53)
                        .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(79, 79, 79)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(history)
                .addGap(14, 14, 14))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btn_search, javax.swing.GroupLayout.PREFERRED_SIZE, 64, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(text_search, javax.swing.GroupLayout.PREFERRED_SIZE, 64, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(history, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void btn_searchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_searchActionPerformed
        // TODO add your handling code here:
        if(evt.getSource() == btn_search){
            lblpicture.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pictures/loading-ezgif.com-resize (1).gif")));
            //getting the search from the jtextfield to pass it
            search = text_search.getText();
            try{
                //this is used to turn the api to json. and the search string is to change the api link                 
                System.out.println("loading..");               
                ApiToJson(apiconnect(search));
                System.out.println("done");
                
            }catch(Exception e){
                e.printStackTrace();
            }     
            again = true;
            fav.setIcon(new ImageIcon("C:\\Users\\CK\\Downloads\\empty_star-removebg-preview.png"));
        }
        String id = "";
        in = 5000;
        try{
            Connection con = db_connect.connect();
            String FindID = "SELECT * FROM tbl_account WHERE username=? AND password=?";
            String counted = "SELECT COUNT(*) AS MAX FROM tbl_history WHERE account_id=?";
            //getting id
            try(PreparedStatement st = con.prepareStatement(FindID)){
                st.setString(1, loginn.user);
                st.setString(2,loginn.pass);
                ResultSet rs = st.executeQuery();
                if(rs.next()){
                    id = rs.getString("account_id");
                }
                else System.out.println("No account found!");
            }
            //counting the max column
            try(PreparedStatement sts = con.prepareStatement(counted)){
                sts.setString(1,id);
                ResultSet rss = sts.executeQuery();
                if(rss.next()){
                    if(rss.getInt("MAX") >0){
                        findingfavorite();
                    }
                }else System.out.println("LOL");
            }
        }catch(Exception e){
            e.printStackTrace();
        };
       
        
    }//GEN-LAST:event_btn_searchActionPerformed

    private void btn_searchMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btn_searchMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_btn_searchMouseClicked
    private String search;
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(PokemonFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(PokemonFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(PokemonFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(PokemonFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new PokemonFrame("").setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btn_search;
    private javax.swing.JLabel fav;
    private javax.swing.JLabel history;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JLabel lbl_name;
    private javax.swing.JLabel lblability1;
    private javax.swing.JLabel lblability2;
    private javax.swing.JLabel lblid;
    private javax.swing.JLabel lblpicture;
    private javax.swing.JTextField text_search;
    // End of variables declaration//GEN-END:variables
}
