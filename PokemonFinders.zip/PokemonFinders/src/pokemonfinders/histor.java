/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package pokemonfinders;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.net.URL;
import javax.swing.table.DefaultTableModel;
import java.sql.*;
import java.util.*;
import javax.swing.ImageIcon;

/**
 *
 * @author CK
 */
public class histor extends javax.swing.JFrame {

    /**
     * Creates new form histor
     */
    public histor() {
        initComponents();
        Determinedthepanel();
        checkingextra();
        displayingdetails();
    }
    private String account_id;
    private int exc;
    private int counted;
    private String view="";
    private int a=0,b=1,c=2,d=3,q=4;
    private boolean entry = false;
    private String data[] = new String[5];
    
    //process for panel
    private void Determinedthepanel(){
        loginn s = new loginn();
        Connection con = db_connect.connect();
        ResultSet rs = null;
        String count="";
        try{
            String gettingid = "SELECT * FROM tbl_account WHERE username=? and password=?";
            String countfav = "SELECT COUNT(account_id) AS countedfavorite FROM tbl_history WHERE account_id=?";  
            //getting the account id
            try(PreparedStatement sts = con.prepareStatement(gettingid)){
                sts.setString(1, loginn.user);
                sts.setString(2, loginn.pass);
                rs = sts.executeQuery();
                if(rs.next()){
                    account_id = rs.getString("account_id");
                    lbl_name.setText(rs.getString("firstname") + rs.getString("lastname"));
                    lbl_email.setText(rs.getString("email"));
                    System.out.println(account_id + " is the account");
                }
                else System.out.println("NO account found");
            }
            //counting the total favorite 
            try(PreparedStatement st = con.prepareStatement(countfav)){
                st.setString(1,account_id);
                ResultSet rss = st.executeQuery();
                if(rss.next()){
                    count = rss.getString("countedfavorite");                    
                    System.out.println(count + "is how many favorite");
                }
                else System.out.println("no way");
            }
            counted = Integer.parseInt(count);
            exc = 14;
            boolean on = true;
            boolean off = false;
            //if fav is zero
            if(counted == 0){
                removepanel(off,off,off,off,off);
            }
            //auto remove panel
            switch (counted){
                case 1:removepanel(on,off,off,off,off);adjustframe(365);break;
                case 2:removepanel(on,on,off,off,off);adjustframe(495);break;
                case 3:removepanel(on,on,on,off,off);adjustframe(625);break;
                case 4:removepanel(on,on,on,on,off);adjustframe(755);break;
                case 5:removepanel(on,on,on,on,on);adjustframe(885);break;
                default:removepanel(on,on,on,on,on);adjustframe(885);System.out.println(counted);counted = counted - 5;next.setVisible(true);break;
            }
        }catch(Exception e){
            e.printStackTrace();
        }
    }
    private void checkingextra(){
        next.addMouseListener(new MouseAdapter() {
                @Override
                public void mouseClicked(MouseEvent e) {
                    if(entry){
                        boolean on = true;
                        boolean off = false;
                        System.out.println("oh you are already here");
                        a = a + 5;b = b + 5;c = c + 5;d = d + 5;q = q + 5;
                        //auto remove panel
                        switch (counted){
                            case 1:removepanel(on,off,off,off,off);adjustframe(365);break;
                            case 2:removepanel(on,on,off,off,off);adjustframe(495);break;
                            case 3:removepanel(on,on,on,off,off);adjustframe(625);break;
                            case 4:removepanel(on,on,on,on,off);adjustframe(755);break;
                            case 5:removepanel(on,on,on,on,on);adjustframe(885);break;
                            default:removepanel(on,on,on,on,on);adjustframe(885);System.out.println(counted);counted = counted - 5;next.setVisible(true);break;
                        }
                        //display detail
                        displayingdetails();
                    }
                        
                }
            });
    }  
    //1st panel
    private void panelA(String info[]){
        try{
            URL link = new URL(info[1]);
            ImageIcon icon = new ImageIcon(link);
            name1.setText(info[2]);
            time1.setText(info[4]);
            img1.setIcon(icon);
            view = info[2];
        }catch(Exception e){
            System.out.println(e);
        }
    }
    //2nd panel
    private void panelB(String info[]){
        try{
            URL link = new URL(info[1]);
            ImageIcon icon = new ImageIcon(link);
            name2.setText(info[2]);
            time2.setText(info[4]);
            img2.setIcon(icon);
            view = info[2];
        }catch(Exception e){
            System.out.println(e);
        }
    }
    //3rd panel
    private void panelC(String info[]){
        try{
            URL link = new URL(info[1]);
            ImageIcon icon = new ImageIcon(link);
            name3.setText(info[2]);
            time3.setText(info[4]);
            img3.setIcon(icon);
            view = info[2];
        }catch(Exception e){
            System.out.println(e);
        }
    }
    //4th panel
    private void panelD(String info[]){
        try{
            URL link = new URL(info[1]);
            ImageIcon icon = new ImageIcon(link);
            name4.setText(info[2]);
            time4.setText(info[4]);
            img4.setIcon(icon);
            view = info[2];
        }catch(Exception e){
            System.out.println(e);
        }
    }
    //5th panel
    private void panelE(String info[]){
        try{
            URL link = new URL(info[1]);
            ImageIcon icon = new ImageIcon(link);
            name5.setText(info[2]);
            time5.setText(info[4]);
            img5.setIcon(icon);
            view = info[2];
        }catch(Exception e){
            System.out.println(e);
        }
    }   
    private void insertingdata(ArrayList<String[]> detail){
        try{
            panelA(detail.get(a));
            panelB(detail.get(b));
            panelC(detail.get(c));
            panelD(detail.get(d));
            panelE(detail.get(q)); 
            
            
        }catch(Exception x){
            System.out.println("Dont worry its not an error :))");
        }              
    }
    //add action listener to delete button
    private void buttonlisten(ActionListener buttonListener){
        delete1.addActionListener(buttonListener);
        delete2.addActionListener(buttonListener);
        delete3.addActionListener(buttonListener);
        delete4.addActionListener(buttonListener);
        delete5.addActionListener(buttonListener);
    }
    //display details
    private void displayingdetails(){        
        Connection con = db_connect.connect();
        int min = 0;        
        int max = 0;
        String date = "";
        ArrayList<String[]> details = new ArrayList<>();
        try{
            String GETTINGLOWEST = "SELECT min(pokemon_id) AS Lowest FROM tbl_history WHERE account_id=?";
            String GETTINGHIGHEST = "SELECT max(pokemon_id) AS Highest FROM tbl_history WHERE account_id=?";
            String GETDETAILS = "SELECT * FROM tbl_api WHERE pokemon_id=? AND account_id=?";
            String GETTINGTIME = "SELECT * FROM tbl_history WHERE pokemon_id=? AND account_id=?";
            //getting the  lowest id
            try(PreparedStatement st = con.prepareStatement(GETTINGLOWEST)){
                st.setString(1, account_id);
                ResultSet rst = st.executeQuery();
                if(rst.next()){
                    min = rst.getInt("Lowest");
                    System.out.println("Succsessfull found the lowest = "+min );
                }else System.out.println("NO account found");
            }            
            //getting the highest id
            try(PreparedStatement sts = con.prepareStatement(GETTINGHIGHEST)){
                sts.setString(1, account_id);
                lblID.setText(account_id);
                ResultSet rs = sts.executeQuery();
                if(rs.next()){
                    max = rs.getInt("Highest");
                    System.out.println("Succsessfull found the highest =" + max);
                }else System.out.println("NO account found");
            }           
            //getting details
            try(PreparedStatement stt = con.prepareStatement(GETDETAILS)){                   
                for(int x = min;x-5000<=max-5000;x++){
                    stt.setString(1, String.valueOf(x));
                    stt.setString(2, account_id);
                    ResultSet rss = stt.executeQuery();
                    //getting the  time on tbl_history 
                    try(PreparedStatement sst = con.prepareStatement(GETTINGTIME)){
                        sst.setString(1,String.valueOf(x));
                        sst.setString(2, account_id);
                        ResultSet result = sst.executeQuery();
                        if(result.next()){
                            date = result.getString("time");
                            System.out.println("Succsessfull found the date" + date);
                        }
                    }
                    if(rss.next()){
                        String detail[] = {rss.getString("id"),rss.getString("picture"),rss.getString("name"),rss.getString("account_id"),date,rss.getString("pokemon_id")};
                        details.add(detail);
                        System.out.println("Successfull inserted into arraylist");
                    }
                    else System.out.println("insert failed to array");                   
                }   
                
            }
            for(String[] array : details){
                System.out.println(Arrays.toString(array) + "<<<****");
            }
            ActionListener buttonListener = new ActionListener() {
                
            @Override
                public void actionPerformed(ActionEvent e) {

                    if (e.getSource() == delete1) {
                        DeleteFav(details.get(a));
                        displayingdetails();
                    } else if (e.getSource() == delete2) {
                        DeleteFav(details.get(b));
                        displayingdetails();
                    }
                    else if(e.getSource() == delete3){
                        DeleteFav(details.get(c));
                        displayingdetails();
                    }
                    else if(e.getSource() == delete4){
                        DeleteFav(details.get(d));
                        displayingdetails();                        
                    }
                    else if(e.getSource() == delete5){
                        DeleteFav(details.get(q));
                        displayingdetails();
                    }
                }
                
            };
            System.out.println("nigga");
            buttonlisten(buttonListener);
            //print the details to frame
            insertingdata(details);
            System.out.println("niggers");
            entry = true;
            System.out.println("you are now allowed to pass" + entry);
            
        }catch(Exception e){
            System.out.println(e);
        }
    }
    //used to remove panel and adjust the panel 
    private void removepanel(boolean a,boolean b,boolean c,boolean d,boolean e){
        if(a){
            panel1.setVisible(a);
            panel11.setVisible(a);
        }
        if(b){
            panel2.setVisible(b);
            panel22.setVisible(b);
        }
        if(c){
            panel3.setVisible(c);
            panel33.setVisible(c);
        }
        if(d){
            panel4.setVisible(d);
            panel44.setVisible(d);
        }
        if(e){
            panel5.setVisible(e);
            panel55.setVisible(e);
        }
    }
    //adjust frame defending on how many panel you have
    private void adjustframe(int y){
        setSize(741,y);
    }
    //used only to remove
    private void removepanel(){
        boolean on = true;
        boolean off = false;
        if(counted == 0){
                removepanel(off,off,off,off,off);
        }
        switch (counted){
            case 1:removepanel(on,off,off,off,off);adjustframe(365);break;
            case 2:removepanel(on,on,off,off,off);adjustframe(495);break;
            case 3:removepanel(on,on,on,off,off);adjustframe(625);break;
            case 4:removepanel(on,on,on,on,off);adjustframe(755);break;
            case 5:removepanel(on,on,on,on,on);adjustframe(885);break;
            default:removepanel(on,on,on,on,on);adjustframe(885);System.out.println(counted);counted = counted - 5;next.setVisible(true);break;
        }
    }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel5 = new javax.swing.JPanel();
        jLabel31 = new javax.swing.JLabel();
        jLabel32 = new javax.swing.JLabel();
        jLabel33 = new javax.swing.JLabel();
        jLabel34 = new javax.swing.JLabel();
        jLabel35 = new javax.swing.JLabel();
        jLabel36 = new javax.swing.JLabel();
        jLabel37 = new javax.swing.JLabel();
        jLabel38 = new javax.swing.JLabel();
        jLabel39 = new javax.swing.JLabel();
        jLabel40 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jLabel51 = new javax.swing.JLabel();
        jPanel8 = new javax.swing.JPanel();
        jLabel26 = new javax.swing.JLabel();
        lblID = new javax.swing.JLabel();
        jLabel28 = new javax.swing.JLabel();
        lbl_name = new javax.swing.JLabel();
        jLabel30 = new javax.swing.JLabel();
        lbl_email = new javax.swing.JLabel();
        panel1 = new javax.swing.JPanel();
        img1 = new javax.swing.JLabel();
        panel2 = new javax.swing.JPanel();
        img2 = new javax.swing.JLabel();
        panel4 = new javax.swing.JPanel();
        img4 = new javax.swing.JLabel();
        panel5 = new javax.swing.JPanel();
        img5 = new javax.swing.JLabel();
        panel3 = new javax.swing.JPanel();
        img3 = new javax.swing.JLabel();
        panel22 = new javax.swing.JPanel();
        jLabel10 = new javax.swing.JLabel();
        time2 = new javax.swing.JLabel();
        name2 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        delete2 = new javax.swing.JButton();
        view2 = new javax.swing.JButton();
        jPanel10 = new javax.swing.JPanel();
        panel55 = new javax.swing.JPanel();
        jLabel22 = new javax.swing.JLabel();
        time5 = new javax.swing.JLabel();
        name5 = new javax.swing.JLabel();
        jLabel25 = new javax.swing.JLabel();
        delete5 = new javax.swing.JButton();
        view5 = new javax.swing.JButton();
        panel33 = new javax.swing.JPanel();
        jLabel14 = new javax.swing.JLabel();
        time3 = new javax.swing.JLabel();
        name3 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        delete3 = new javax.swing.JButton();
        view3 = new javax.swing.JButton();
        panel44 = new javax.swing.JPanel();
        jLabel18 = new javax.swing.JLabel();
        time4 = new javax.swing.JLabel();
        name4 = new javax.swing.JLabel();
        jLabel21 = new javax.swing.JLabel();
        delete4 = new javax.swing.JButton();
        view4 = new javax.swing.JButton();
        next = new javax.swing.JLabel();
        prev = new javax.swing.JLabel();
        panel11 = new javax.swing.JPanel();
        jLabel27 = new javax.swing.JLabel();
        time1 = new javax.swing.JLabel();
        name1 = new javax.swing.JLabel();
        jLabel42 = new javax.swing.JLabel();
        delete1 = new javax.swing.JButton();
        view1 = new javax.swing.JButton();

        jPanel5.setBackground(new java.awt.Color(204, 204, 204));

        jLabel31.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pictures/6.png"))); // NOI18N

        jLabel32.setForeground(new java.awt.Color(51, 51, 51));
        jLabel32.setText("Name :");

        jLabel33.setForeground(new java.awt.Color(51, 51, 51));
        jLabel33.setText("Charizard");

        jLabel34.setForeground(new java.awt.Color(51, 51, 51));
        jLabel34.setText("Ability 1 :");

        jLabel35.setForeground(new java.awt.Color(51, 51, 51));
        jLabel35.setText("Ability 2 :");

        jLabel36.setForeground(new java.awt.Color(51, 51, 51));
        jLabel36.setText("I.D :");

        jLabel37.setForeground(new java.awt.Color(51, 51, 51));
        jLabel37.setText("jLabel7");

        jLabel38.setForeground(new java.awt.Color(51, 51, 51));
        jLabel38.setText("jLabel8");

        jLabel39.setForeground(new java.awt.Color(51, 51, 51));
        jLabel39.setText("jLabel9");

        jLabel40.setForeground(new java.awt.Color(51, 51, 51));
        jLabel40.setText("Date :");

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel31)
                .addGap(41, 41, 41)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addComponent(jLabel35)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel38))
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel5Layout.createSequentialGroup()
                                .addComponent(jLabel32)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jLabel33))
                            .addGroup(jPanel5Layout.createSequentialGroup()
                                .addComponent(jLabel34)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jLabel37)))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel40)
                            .addGroup(jPanel5Layout.createSequentialGroup()
                                .addComponent(jLabel36)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jLabel39)))))
                .addContainerGap(120, Short.MAX_VALUE))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGap(19, 19, 19)
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel32)
                            .addComponent(jLabel33)
                            .addComponent(jLabel36)
                            .addComponent(jLabel39))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel34)
                            .addComponent(jLabel37)
                            .addComponent(jLabel40))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel35)
                            .addComponent(jLabel38))
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel31, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addContainerGap())
        );

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(255, 153, 51));

        jLabel51.setFont(new java.awt.Font("Segoe UI", 1, 48)); // NOI18N
        jLabel51.setForeground(new java.awt.Color(0, 0, 0));
        jLabel51.setText("Bookmarks");

        jPanel8.setBackground(new java.awt.Color(204, 204, 204));

        jLabel26.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel26.setForeground(new java.awt.Color(51, 51, 51));
        jLabel26.setText("Account ID :");

        lblID.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lblID.setForeground(new java.awt.Color(51, 51, 51));
        lblID.setText("?");

        jLabel28.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel28.setForeground(new java.awt.Color(51, 51, 51));
        jLabel28.setText("Name :");

        lbl_name.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lbl_name.setForeground(new java.awt.Color(51, 51, 51));
        lbl_name.setText("????????????????????");

        jLabel30.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel30.setForeground(new java.awt.Color(51, 51, 51));
        jLabel30.setText("Email :");

        lbl_email.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lbl_email.setForeground(new java.awt.Color(51, 51, 51));
        lbl_email.setText("??????????????@gmail.com");

        javax.swing.GroupLayout jPanel8Layout = new javax.swing.GroupLayout(jPanel8);
        jPanel8.setLayout(jPanel8Layout);
        jPanel8Layout.setHorizontalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addGap(45, 45, 45)
                .addComponent(jLabel26)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lblID)
                .addGap(18, 18, 18)
                .addComponent(jLabel28)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lbl_name)
                .addGap(18, 18, 18)
                .addComponent(jLabel30)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lbl_email)
                .addContainerGap(108, Short.MAX_VALUE))
        );
        jPanel8Layout.setVerticalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel8Layout.createSequentialGroup()
                .addContainerGap(46, Short.MAX_VALUE)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel26)
                    .addComponent(jLabel28)
                    .addComponent(lbl_name)
                    .addComponent(jLabel30)
                    .addComponent(lbl_email)
                    .addComponent(lblID))
                .addGap(42, 42, 42))
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(190, 190, 190)
                .addComponent(jLabel51)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addComponent(jPanel8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel51)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 713, -1));

        panel1.setVisible(false);
        panel1.setBackground(new java.awt.Color(204, 204, 204));

        img1.setText("????");

        javax.swing.GroupLayout panel1Layout = new javax.swing.GroupLayout(panel1);
        panel1.setLayout(panel1Layout);
        panel1Layout.setHorizontalGroup(
            panel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel1Layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addComponent(img1, javax.swing.GroupLayout.PREFERRED_SIZE, 91, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(17, Short.MAX_VALUE))
        );
        panel1Layout.setVerticalGroup(
            panel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel1Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addComponent(img1, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(15, Short.MAX_VALUE))
        );

        getContentPane().add(panel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 200, -1, -1));

        panel2.setVisible(false);
        panel2.setBackground(new java.awt.Color(255, 153, 51));

        img2.setText("???");

        javax.swing.GroupLayout panel2Layout = new javax.swing.GroupLayout(panel2);
        panel2.setLayout(panel2Layout);
        panel2Layout.setHorizontalGroup(
            panel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel2Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(img2, javax.swing.GroupLayout.PREFERRED_SIZE, 93, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(17, Short.MAX_VALUE))
        );
        panel2Layout.setVerticalGroup(
            panel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel2Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(img2, javax.swing.GroupLayout.PREFERRED_SIZE, 92, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(14, Short.MAX_VALUE))
        );

        getContentPane().add(panel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 330, -1, -1));

        panel4.setVisible(false);
        panel4.setBackground(new java.awt.Color(255, 153, 51));

        img4.setText("????");

        javax.swing.GroupLayout panel4Layout = new javax.swing.GroupLayout(panel4);
        panel4.setLayout(panel4Layout);
        panel4Layout.setHorizontalGroup(
            panel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel4Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addComponent(img4, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(14, Short.MAX_VALUE))
        );
        panel4Layout.setVerticalGroup(
            panel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel4Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addComponent(img4, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(15, Short.MAX_VALUE))
        );

        getContentPane().add(panel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 590, -1, -1));

        panel5.setVisible(false);
        panel5.setBackground(new java.awt.Color(204, 204, 204));

        img5.setText("????");

        javax.swing.GroupLayout panel5Layout = new javax.swing.GroupLayout(panel5);
        panel5.setLayout(panel5Layout);
        panel5Layout.setHorizontalGroup(
            panel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel5Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addComponent(img5, javax.swing.GroupLayout.PREFERRED_SIZE, 94, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(15, Short.MAX_VALUE))
        );
        panel5Layout.setVerticalGroup(
            panel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel5Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addComponent(img5, javax.swing.GroupLayout.PREFERRED_SIZE, 91, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(14, Short.MAX_VALUE))
        );

        getContentPane().add(panel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 720, -1, -1));

        panel3.setVisible(false);
        panel3.setBackground(new java.awt.Color(204, 204, 204));

        img3.setText("????");

        javax.swing.GroupLayout panel3Layout = new javax.swing.GroupLayout(panel3);
        panel3.setLayout(panel3Layout);
        panel3Layout.setHorizontalGroup(
            panel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel3Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addComponent(img3, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(14, Short.MAX_VALUE))
        );
        panel3Layout.setVerticalGroup(
            panel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel3Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addComponent(img3, javax.swing.GroupLayout.PREFERRED_SIZE, 91, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(14, Short.MAX_VALUE))
        );

        getContentPane().add(panel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 460, -1, -1));

        panel22.setVisible(false);
        panel22.setBackground(new java.awt.Color(255, 153, 51));

        jLabel10.setForeground(new java.awt.Color(51, 51, 51));
        jLabel10.setText("Time of favorite :");

        time2.setForeground(new java.awt.Color(51, 51, 51));
        time2.setText("2024-05-05");

        name2.setForeground(new java.awt.Color(51, 51, 51));
        name2.setText("???");

        jLabel13.setForeground(new java.awt.Color(51, 51, 51));
        jLabel13.setText("Name :");

        delete2.setBackground(new java.awt.Color(255, 102, 102));
        delete2.setFont(new java.awt.Font("MS Reference Sans Serif", 1, 12)); // NOI18N
        delete2.setForeground(new java.awt.Color(255, 255, 255));
        delete2.setText("Delete");
        delete2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                delete2ActionPerformed(evt);
            }
        });

        view2.setBackground(new java.awt.Color(51, 102, 255));
        view2.setFont(new java.awt.Font("MS Reference Sans Serif", 1, 12)); // NOI18N
        view2.setForeground(new java.awt.Color(255, 255, 255));
        view2.setText("View");
        view2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                view2ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout panel22Layout = new javax.swing.GroupLayout(panel22);
        panel22.setLayout(panel22Layout);
        panel22Layout.setHorizontalGroup(
            panel22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel22Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(panel22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(panel22Layout.createSequentialGroup()
                        .addComponent(jLabel10)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(time2))
                    .addGroup(panel22Layout.createSequentialGroup()
                        .addComponent(jLabel13)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(name2)))
                .addGap(33, 33, 33)
                .addComponent(view2, javax.swing.GroupLayout.PREFERRED_SIZE, 84, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(delete2)
                .addContainerGap())
        );

        panel22Layout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {delete2, view2});

        panel22Layout.setVerticalGroup(
            panel22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panel22Layout.createSequentialGroup()
                .addContainerGap(42, Short.MAX_VALUE)
                .addGroup(panel22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(panel22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(delete2)
                        .addComponent(view2, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(panel22Layout.createSequentialGroup()
                        .addGroup(panel22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel13)
                            .addComponent(name2))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(panel22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel10)
                            .addComponent(time2))))
                .addGap(34, 34, 34))
        );

        panel22Layout.linkSize(javax.swing.SwingConstants.VERTICAL, new java.awt.Component[] {delete2, view2});

        getContentPane().add(panel22, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 330, -1, -1));

        jPanel10.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        getContentPane().add(jPanel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(670, 202, -1, -1));

        panel55.setBackground(new java.awt.Color(204, 204, 204));
        panel55.setVisible(false);
        panel55.setForeground(new java.awt.Color(204, 204, 204));

        jLabel22.setForeground(new java.awt.Color(51, 51, 51));
        jLabel22.setText("Time of favorite :");

        time5.setForeground(new java.awt.Color(51, 51, 51));
        time5.setText("2024-05-05");

        name5.setForeground(new java.awt.Color(51, 51, 51));
        name5.setText("???");

        jLabel25.setForeground(new java.awt.Color(51, 51, 51));
        jLabel25.setText("Name :");

        delete5.setBackground(new java.awt.Color(255, 102, 102));
        delete5.setFont(new java.awt.Font("MS Reference Sans Serif", 1, 12)); // NOI18N
        delete5.setForeground(new java.awt.Color(255, 255, 255));
        delete5.setText("Delete");
        delete5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                delete5ActionPerformed(evt);
            }
        });

        view5.setBackground(new java.awt.Color(51, 102, 255));
        view5.setFont(new java.awt.Font("MS Reference Sans Serif", 1, 12)); // NOI18N
        view5.setForeground(new java.awt.Color(255, 255, 255));
        view5.setText("View");
        view5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                view5ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout panel55Layout = new javax.swing.GroupLayout(panel55);
        panel55.setLayout(panel55Layout);
        panel55Layout.setHorizontalGroup(
            panel55Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel55Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(panel55Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(panel55Layout.createSequentialGroup()
                        .addComponent(jLabel22)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(time5))
                    .addGroup(panel55Layout.createSequentialGroup()
                        .addComponent(jLabel25)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(name5)))
                .addGap(33, 33, 33)
                .addComponent(view5, javax.swing.GroupLayout.PREFERRED_SIZE, 84, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(delete5)
                .addContainerGap())
        );

        panel55Layout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {delete5, view5});

        panel55Layout.setVerticalGroup(
            panel55Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panel55Layout.createSequentialGroup()
                .addContainerGap(42, Short.MAX_VALUE)
                .addGroup(panel55Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(panel55Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(delete5)
                        .addComponent(view5, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(panel55Layout.createSequentialGroup()
                        .addGroup(panel55Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel25)
                            .addComponent(name5))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(panel55Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel22)
                            .addComponent(time5))))
                .addGap(34, 34, 34))
        );

        panel55Layout.linkSize(javax.swing.SwingConstants.VERTICAL, new java.awt.Component[] {delete5, view5});

        getContentPane().add(panel55, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 720, -1, 120));

        panel33.setBackground(new java.awt.Color(204, 204, 204));
        panel33.setVisible(false);
        panel33.setForeground(new java.awt.Color(204, 204, 204));

        jLabel14.setForeground(new java.awt.Color(51, 51, 51));
        jLabel14.setText("Time of favorite :");

        time3.setForeground(new java.awt.Color(51, 51, 51));
        time3.setText("2024-05-05");

        name3.setForeground(new java.awt.Color(51, 51, 51));
        name3.setText("???");

        jLabel17.setForeground(new java.awt.Color(51, 51, 51));
        jLabel17.setText("Name :");

        delete3.setBackground(new java.awt.Color(255, 102, 102));
        delete3.setFont(new java.awt.Font("MS Reference Sans Serif", 1, 12)); // NOI18N
        delete3.setForeground(new java.awt.Color(255, 255, 255));
        delete3.setText("Delete");
        delete3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                delete3ActionPerformed(evt);
            }
        });

        view3.setBackground(new java.awt.Color(51, 102, 255));
        view3.setFont(new java.awt.Font("MS Reference Sans Serif", 1, 12)); // NOI18N
        view3.setForeground(new java.awt.Color(255, 255, 255));
        view3.setText("View");
        view3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                view3ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout panel33Layout = new javax.swing.GroupLayout(panel33);
        panel33.setLayout(panel33Layout);
        panel33Layout.setHorizontalGroup(
            panel33Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel33Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(panel33Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(panel33Layout.createSequentialGroup()
                        .addComponent(jLabel14)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(time3))
                    .addGroup(panel33Layout.createSequentialGroup()
                        .addComponent(jLabel17)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(name3)))
                .addGap(33, 33, 33)
                .addComponent(view3, javax.swing.GroupLayout.PREFERRED_SIZE, 84, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(delete3)
                .addContainerGap())
        );

        panel33Layout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {delete3, view3});

        panel33Layout.setVerticalGroup(
            panel33Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panel33Layout.createSequentialGroup()
                .addContainerGap(42, Short.MAX_VALUE)
                .addGroup(panel33Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(panel33Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(delete3)
                        .addComponent(view3, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(panel33Layout.createSequentialGroup()
                        .addGroup(panel33Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel17)
                            .addComponent(name3))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(panel33Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel14)
                            .addComponent(time3))))
                .addGap(34, 34, 34))
        );

        panel33Layout.linkSize(javax.swing.SwingConstants.VERTICAL, new java.awt.Component[] {delete3, view3});

        getContentPane().add(panel33, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 460, -1, -1));

        panel44.setBackground(new java.awt.Color(255, 153, 51));
        panel44.setVisible(false);
        panel44.setForeground(new java.awt.Color(204, 204, 204));

        jLabel18.setForeground(new java.awt.Color(51, 51, 51));
        jLabel18.setText("Time of favorite :");

        time4.setForeground(new java.awt.Color(51, 51, 51));
        time4.setText("2024-05-05");

        name4.setForeground(new java.awt.Color(51, 51, 51));
        name4.setText("???");

        jLabel21.setForeground(new java.awt.Color(51, 51, 51));
        jLabel21.setText("Name :");

        delete4.setBackground(new java.awt.Color(255, 102, 102));
        delete4.setFont(new java.awt.Font("MS Reference Sans Serif", 1, 12)); // NOI18N
        delete4.setForeground(new java.awt.Color(255, 255, 255));
        delete4.setText("Delete");
        delete4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                delete4ActionPerformed(evt);
            }
        });

        view4.setBackground(new java.awt.Color(51, 102, 255));
        view4.setFont(new java.awt.Font("MS Reference Sans Serif", 1, 12)); // NOI18N
        view4.setForeground(new java.awt.Color(255, 255, 255));
        view4.setText("View");
        view4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                view4ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout panel44Layout = new javax.swing.GroupLayout(panel44);
        panel44.setLayout(panel44Layout);
        panel44Layout.setHorizontalGroup(
            panel44Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel44Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(panel44Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(panel44Layout.createSequentialGroup()
                        .addComponent(jLabel18)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(time4))
                    .addGroup(panel44Layout.createSequentialGroup()
                        .addComponent(jLabel21)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(name4)))
                .addGap(33, 33, 33)
                .addComponent(view4, javax.swing.GroupLayout.PREFERRED_SIZE, 84, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(delete4)
                .addContainerGap())
        );

        panel44Layout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {delete4, view4});

        panel44Layout.setVerticalGroup(
            panel44Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panel44Layout.createSequentialGroup()
                .addContainerGap(42, Short.MAX_VALUE)
                .addGroup(panel44Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(panel44Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(delete4)
                        .addComponent(view4, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(panel44Layout.createSequentialGroup()
                        .addGroup(panel44Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel21)
                            .addComponent(name4))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(panel44Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel18)
                            .addComponent(time4))))
                .addGap(34, 34, 34))
        );

        panel44Layout.linkSize(javax.swing.SwingConstants.VERTICAL, new java.awt.Component[] {delete4, view4});

        getContentPane().add(panel44, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 590, -1, 120));

        next.setVisible(false);
        next.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pictures/next__1_-removebg-preview.png"))); // NOI18N
        next.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        getContentPane().add(next, new org.netbeans.lib.awtextra.AbsoluteConstraints(630, 760, -1, -1));

        prev.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pictures/prev.png"))); // NOI18N
        prev.setVisible(false);
        getContentPane().add(prev, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 760, -1, 76));

        panel11.setBackground(new java.awt.Color(204, 204, 204));
        panel11.setVisible(false);
        panel11.setForeground(new java.awt.Color(204, 204, 204));

        jLabel27.setForeground(new java.awt.Color(51, 51, 51));
        jLabel27.setText("Time of favorite :");

        time1.setForeground(new java.awt.Color(51, 51, 51));
        time1.setText("2024-05-05");

        name1.setForeground(new java.awt.Color(51, 51, 51));
        name1.setText("???");

        jLabel42.setForeground(new java.awt.Color(51, 51, 51));
        jLabel42.setText("Name :");

        delete1.setBackground(new java.awt.Color(255, 102, 102));
        delete1.setFont(new java.awt.Font("MS Reference Sans Serif", 1, 12)); // NOI18N
        delete1.setForeground(new java.awt.Color(255, 255, 255));
        delete1.setText("Delete");
        delete1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                delete1ActionPerformed(evt);
            }
        });

        view1.setBackground(new java.awt.Color(51, 102, 255));
        view1.setFont(new java.awt.Font("MS Reference Sans Serif", 1, 12)); // NOI18N
        view1.setForeground(new java.awt.Color(255, 255, 255));
        view1.setText("View");
        view1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                view1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout panel11Layout = new javax.swing.GroupLayout(panel11);
        panel11.setLayout(panel11Layout);
        panel11Layout.setHorizontalGroup(
            panel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel11Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(panel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(panel11Layout.createSequentialGroup()
                        .addComponent(jLabel27)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(time1))
                    .addGroup(panel11Layout.createSequentialGroup()
                        .addComponent(jLabel42)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(name1)))
                .addGap(33, 33, 33)
                .addComponent(view1, javax.swing.GroupLayout.PREFERRED_SIZE, 84, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(delete1)
                .addContainerGap())
        );

        panel11Layout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {delete1, view1});

        panel11Layout.setVerticalGroup(
            panel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panel11Layout.createSequentialGroup()
                .addContainerGap(42, Short.MAX_VALUE)
                .addGroup(panel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(panel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(delete1)
                        .addComponent(view1, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(panel11Layout.createSequentialGroup()
                        .addGroup(panel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel42)
                            .addComponent(name1))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(panel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel27)
                            .addComponent(time1))))
                .addGap(34, 34, 34))
        );

        panel11Layout.linkSize(javax.swing.SwingConstants.VERTICAL, new java.awt.Component[] {delete1, view1});

        getContentPane().add(panel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 200, -1, -1));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void view(String views){
        dispose();
        new PokemonFrame(views).setVisible(true);
        PokemonFrame.apiconnect(views);        
    }
    private void view1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_view1ActionPerformed
        view(name1.getText());
    }//GEN-LAST:event_view1ActionPerformed

    private void delete1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_delete1ActionPerformed
        counted--;
        removepanel();
    }//GEN-LAST:event_delete1ActionPerformed

    private void delete2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_delete2ActionPerformed
        counted--;
        removepanel();
    }//GEN-LAST:event_delete2ActionPerformed

    private void delete3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_delete3ActionPerformed
        counted--;
        removepanel();
    }//GEN-LAST:event_delete3ActionPerformed

    private void delete4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_delete4ActionPerformed
        counted--;
        removepanel();
    }//GEN-LAST:event_delete4ActionPerformed

    private void delete5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_delete5ActionPerformed
        counted--;
        removepanel();
        
    }//GEN-LAST:event_delete5ActionPerformed

    private void view2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_view2ActionPerformed
        view(name2.getText());
    }//GEN-LAST:event_view2ActionPerformed

    private void view3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_view3ActionPerformed
        view(name3.getText());
    }//GEN-LAST:event_view3ActionPerformed

    private void view4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_view4ActionPerformed
        view(name4.getText());
    }//GEN-LAST:event_view4ActionPerformed

    private void view5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_view5ActionPerformed
        view(name5.getText());
    }//GEN-LAST:event_view5ActionPerformed
    //delete favorite
    private void DeleteFav(String detail[]){
        System.out.println(detail[0] + " "+ detail[3] + "************************");
        try{
            String DeleteRec = "DELETE FROM tbl_history WHERE pokemon_id=? AND account_id=?";
            Connection con = db_connect.connect();
            try(PreparedStatement st = con.prepareStatement(DeleteRec)){
                st.setString(1, detail[5]);
                st.setString(2, detail[3]);
                int result = st.executeUpdate();
                System.out.println("nigga");
                if(result >0){
                    System.out.println("Remove successfully" + result);
                }
            }
        }catch(Exception e){
            System.out.println(e);
        }
    }
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(histor.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(histor.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(histor.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(histor.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new histor().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton delete1;
    private javax.swing.JButton delete2;
    private javax.swing.JButton delete3;
    private javax.swing.JButton delete4;
    private javax.swing.JButton delete5;
    private javax.swing.JLabel img1;
    private javax.swing.JLabel img2;
    private javax.swing.JLabel img3;
    private javax.swing.JLabel img4;
    private javax.swing.JLabel img5;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel30;
    private javax.swing.JLabel jLabel31;
    private javax.swing.JLabel jLabel32;
    private javax.swing.JLabel jLabel33;
    private javax.swing.JLabel jLabel34;
    private javax.swing.JLabel jLabel35;
    private javax.swing.JLabel jLabel36;
    private javax.swing.JLabel jLabel37;
    private javax.swing.JLabel jLabel38;
    private javax.swing.JLabel jLabel39;
    private javax.swing.JLabel jLabel40;
    private javax.swing.JLabel jLabel42;
    private javax.swing.JLabel jLabel51;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JLabel lblID;
    private javax.swing.JLabel lbl_email;
    private javax.swing.JLabel lbl_name;
    private javax.swing.JLabel name1;
    private javax.swing.JLabel name2;
    private javax.swing.JLabel name3;
    private javax.swing.JLabel name4;
    private javax.swing.JLabel name5;
    private javax.swing.JLabel next;
    private javax.swing.JPanel panel1;
    private javax.swing.JPanel panel11;
    private javax.swing.JPanel panel2;
    private javax.swing.JPanel panel22;
    private javax.swing.JPanel panel3;
    private javax.swing.JPanel panel33;
    private javax.swing.JPanel panel4;
    private javax.swing.JPanel panel44;
    private javax.swing.JPanel panel5;
    private javax.swing.JPanel panel55;
    private javax.swing.JLabel prev;
    private javax.swing.JLabel time1;
    private javax.swing.JLabel time2;
    private javax.swing.JLabel time3;
    private javax.swing.JLabel time4;
    private javax.swing.JLabel time5;
    private javax.swing.JButton view1;
    private javax.swing.JButton view2;
    private javax.swing.JButton view3;
    private javax.swing.JButton view4;
    private javax.swing.JButton view5;
    // End of variables declaration//GEN-END:variables
}
