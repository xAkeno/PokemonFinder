/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pokemonfinders;
import java.sql.*;
/**
 *
 * @author CK
 */
public class db_connect {
    public static Connection connect(){
        Connection connect = null;
        try{
            Class.forName("com.mysql.jdbc.Driver");
            connect = DriverManager.getConnection( "jdbc:mysql://localhost:3306/db_pokemonefinder","root","");
            return connect;
        }catch(Exception e){
            e.printStackTrace();
        }
        return null;
    }
}
